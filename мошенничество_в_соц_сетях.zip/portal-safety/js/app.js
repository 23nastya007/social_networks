﻿// ============================================================
// ЗАДАНИЕ 2: ПЕРЕКЛЮЧАТЕЛЬ ТЕМЫ (работает на всех страницах)
// ============================================================
(function ($) {
  var STORAGE_KEY = 'socshield-theme';
  var $html = $('html');

  // Применяем сохранённую тему СРАЗУ при загрузке (на любой странице)
  try {
    if (localStorage.getItem(STORAGE_KEY) === 'light') {
      $html.addClass('theme-light');
    }
  } catch (e) { /* localStorage может быть недоступен */ }

  // Если на странице есть переключатель — настраиваем его
  var $toggle = $('.theme-toggle');
  if (!$toggle.length) return;

  function updateToggleUI() {
    var isLight = $html.hasClass('theme-light');
    // ИЗМЕНЕНО: Текст всегда "Смена темы"
    $toggle.find('.theme-toggle__label').text('Смена темы'); 
    $toggle.attr('aria-pressed', isLight ? 'true' : 'false');
    $toggle.attr('title',
      isLight
        ? 'Включить тёмную тему оформления'
        : 'Включить светлую тему оформления'
    );
  }

  updateToggleUI();

  $toggle.on('click', function () {
    $html.toggleClass('theme-light');
    try {
      localStorage.setItem(
        STORAGE_KEY,
        $html.hasClass('theme-light') ? 'light' : 'dark'
      );
    } catch (e) {}
    updateToggleUI();
  });
})(jQuery);

// ============================================================
// ЗАДАНИЕ 4 + 5 + 6: ЧЕК-ЛИСТ (jQuery-версия)
// ============================================================
(function ($) {
  var $items = $('.checklist__item');
  if (!$items.length) return;

  var STORAGE_KEY = 'socshield-checklist';
  var $summary = $('#checklist-summary');
  var $percent = $('#checklist-percent');
  var $fill    = $('#checklist-fill');
  var $note    = $('#checklist-note');

  function updateItem($item) {
    var $fail = $item.find('.checklist__opt--fail input');
    var $textarea = $item.find('.checklist__textarea');

    if ($fail.prop('checked')) {
      $item.addClass('checklist__item--fail');
      if (!$textarea.val()) {
        var q = $item.find('.checklist__text').text().trim();
        $textarea.val(
          'Требование не выполнено: «' + q +
          '». Необходимо доработать соответствующий элемент портала.'
        );
      }
    } else {
      $item.removeClass('checklist__item--fail');
      $textarea.val('');
    }
  }

  function updateSummary() {
    var total = $items.length;
    var ok = 0;
    var answered = 0;

    $items.each(function () {
      var $i = $(this);
      if ($i.find('.checklist__opt:not(.checklist__opt--fail) input').prop('checked')) {
        ok++; answered++;
      }
      if ($i.find('.checklist__opt--fail input').prop('checked')) {
        answered++;
      }
    });

    $summary.removeClass('checklist-summary--high checklist-summary--mid checklist-summary--low');

    if (answered === 0) {
      $percent.text('—');
      $fill.css('width', '0%');
      $note.text('Отметьте все позиции, чтобы увидеть результат.');
      return;
    }

    var percent = Math.round((ok / total) * 100);
    $percent.text(percent + '%');
    $fill.css('width', percent + '%');

    if (percent >= 80) {
      $summary.addClass('checklist-summary--high');
      $note.text('Высокий уровень соответствия — портал полностью готов.');
    } else if (percent >= 50) {
      $summary.addClass('checklist-summary--mid');
      $note.text('Удовлетворительный уровень — есть замечания, требующие доработки.');
    } else {
      $summary.addClass('checklist-summary--low');
      $note.text('Есть несоответствия — требуется существенная доработка портала.');
    }
  }

  function saveState() {
    var data = {};
    $items.each(function (i) {
      var $i = $(this);
      data['item-' + i] = {
        ok: $i.find('.checklist__opt:not(.checklist__opt--fail) input').prop('checked'),
        fail: $i.find('.checklist__opt--fail input').prop('checked'),
        comment: $i.find('.checklist__textarea').val()
      };
    });
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(data)); } catch (e) {}
  }

  function loadState() {
    var raw = null;
    try { raw = localStorage.getItem(STORAGE_KEY); } catch (e) { return; }
    if (!raw) return;

    var data;
    try { data = JSON.parse(raw); } catch (e) { return; }

    $items.each(function (i) {
      var saved = data['item-' + i];
      if (!saved) return;
      var $i = $(this);

      if (saved.ok)   $i.find('.checklist__opt:not(.checklist__opt--fail) input').prop('checked', true);
      if (saved.fail) $i.find('.checklist__opt--fail input').prop('checked', true);
      if (saved.fail && saved.comment) $i.find('.checklist__textarea').val(saved.comment);

      $i.toggleClass('checklist__item--fail', !!saved.fail);
    });
  }

  function clearState() {
    try { localStorage.removeItem(STORAGE_KEY); } catch (e) {}

    $items.each(function () {
      var $i = $(this);
      $i.find('input[type="radio"]').prop('checked', false);
      $i.find('.checklist__textarea').val('');
      $i.removeClass('checklist__item--fail');
    });

    updateSummary();
  }

  $items.each(function () { updateItem($(this)); });

  $items.on('change', 'input[type="radio"]', function () {
    updateItem($(this).closest('.checklist__item'));
    updateSummary();
    saveState();
  });

  $items.on('input', '.checklist__textarea', saveState);

  $('#checklist-clear').on('click', function () {
    if (window.confirm('Очистить все результаты проверки? Это действие нельзя отменить.')) {
      clearState();
    }
  });

  loadState();
  updateSummary();
})(jQuery);

// ============================================================
// ЗАДАНИЕ 7: МОДАЛЬНОЕ ОКНО (jQuery-версия)
// ============================================================
(function ($) {
  var $modal = $('#modal-1');
  if (!$modal.length) return;

  var $openBtn = $('#open-modal-1');
  var lastFocused = null;

  function openModal() {
    lastFocused = document.activeElement;
    $modal.prop('hidden', false);
    $('body').addClass('modal-open');
    $modal.find('.modal__close').trigger('focus');

    $(document).on('keydown.modal', function (e) {
      if (e.key === 'Escape' || e.key === 'Esc') closeModal();
    });
  }

  function closeModal() {
    $modal.prop('hidden', true);
    $('body').removeClass('modal-open');
    $(document).off('keydown.modal');

    if (lastFocused && lastFocused.focus) lastFocused.focus();
  }

  $openBtn.on('click', openModal);

  $modal.find('[data-modal-close]').on('click', function (e) {
    e.preventDefault();
    closeModal();
  });
})(jQuery);

// ============================================================
// ЗАДАНИЕ 6: ПОИСК И ФИЛЬТРАЦИЯ (главная страница)
// ============================================================
(function ($) {
  var $input = $('#search-input');
  if (!$input.length) return;

  var $clear  = $('#search-clear');
  var $status = $('#search-status');
  var $cards  = $('#sections-grid .section-card');
  var $news   = $('#news-grid .news__item');

  // Сохраняем оригинальный HTML каждой карточки один раз
  $cards.each(function () {
    $(this).data('original-html', $(this).html());
  });
  $news.each(function () {
    $(this).data('original-html', $(this).html());
  });

  // --- Экранирование спецсимволов для RegExp ---
  function escapeRegExp(str) {
    return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  // --- Сброс подсветки: возвращаем оригинальный HTML ---
  function resetHighlight() {
    $cards.each(function () {
      var $c = $(this);
      $c.html($c.data('original-html'));
    });
    $news.each(function () {
      var $n = $(this);
      $n.html($n.data('original-html'));
    });
  }

  // --- Подсветка совпадений через TreeWalker (не ломает вложенные теги) ---
  function highlightElement($el, query) {
    var regex = new RegExp('(' + escapeRegExp(query) + ')', 'gi');
    var el = $el[0];

    var walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT, {
      acceptNode: function (node) {
        if (!node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
        if (node.parentNode &&
            node.parentNode.classList &&
            node.parentNode.classList.contains('search-highlight')) {
          return NodeFilter.FILTER_REJECT;
        }
        return NodeFilter.FILTER_ACCEPT;
      }
    });

    var textNodes = [];
    while (walker.nextNode()) textNodes.push(walker.currentNode);

    textNodes.forEach(function (node) {
      var text = node.nodeValue;
      regex.lastIndex = 0;
      if (!regex.test(text)) return;
      regex.lastIndex = 0;

      var frag = document.createDocumentFragment();
      var lastIndex = 0;
      var m;
      while ((m = regex.exec(text)) !== null) {
        if (m.index > lastIndex) {
          frag.appendChild(document.createTextNode(text.slice(lastIndex, m.index)));
        }
        var span = document.createElement('span');
        span.className = 'search-highlight';
        span.textContent = m[0];
        frag.appendChild(span);
        lastIndex = m.index + m[0].length;
      }
      if (lastIndex < text.length) {
        frag.appendChild(document.createTextNode(text.slice(lastIndex)));
      }
      node.parentNode.replaceChild(frag, node);
    });
  }

  // --- Основная функция фильтрации ---
  function applyFilter() {
    var query = ($input.val() || '').trim().toLowerCase();
    resetHighlight();

    // Пустой запрос — показываем всё
    if (!query) {
      $cards.add($news).removeClass('is-hidden');
      $status.text('Введите запрос, чтобы отфильтровать материалы.');
      return;
    }

    var found = 0;

    $cards.each(function () {
      var $c = $(this);
      var text = $c.text().toLowerCase();
      if (text.indexOf(query) !== -1) {
        $c.removeClass('is-hidden');
        highlightElement($c, query);
        found++;
      } else {
        $c.addClass('is-hidden');
      }
    });

    $news.each(function () {
      var $n = $(this);
      var text = $n.text().toLowerCase();
      if (text.indexOf(query) !== -1) {
        $n.removeClass('is-hidden');
        highlightElement($n, query);
        found++;
      } else {
        $n.addClass('is-hidden');
      }
    });

    if (found === 0) {
      $status.text('По запросу «' + $input.val().trim() + '» ничего не найдено.');
    } else {
      $status.text('Найдено результатов: ' + found + '.');
    }
  }

  // --- Сброс поиска ---
  function resetSearch() {
    $input.val('');
    applyFilter();
    $input.trigger('focus');
  }

  // --- Обработчики ---
  $input.on('input', applyFilter);

  $clear.on('click', resetSearch);

  $input.on('keydown', function (e) {
    if (e.key === 'Escape' || e.keyCode === 27) {
      resetSearch();
    }
  });
})(jQuery);

// ============================================================
// ЗАДАНИЕ 3 + 5 + 6 + 7: КАТАЛОГ ЗАПИСЕЙ
//   — асинхронная загрузка через $.getJSON
//   — индикатор загрузки
//   — обработка ошибки загрузки
//   — фильтрация, сортировка, счётчик
//   — подсветка совпадений (ЗАДАНИЕ 6)
//   — сброс фильтров (ЗАДАНИЕ 6)
//   — сортировка по дате с индикацией направления (ЗАДАНИЕ 7)
// ============================================================
(function ($) {
  var $list = $('#registry-list');
  if (!$list.length) return;

  var $search   = $('#reg-search');
  var $section  = $('#reg-section');
  var $sort     = $('#reg-sort');            // скрытый select (совместимость)
  var $sortBtns = $('.registry-filters__sort-btn'); // кнопки направления (ЗАДАНИЕ 7)
  var $status   = $('#reg-status');
  var $empty    = $('#reg-empty');
  var $reset    = $('#reg-reset');
  var $loading  = $('#reg-loading');
  var $error    = $('#reg-error');
  var $errorTxt = $('#reg-error-text');
  var $retry    = $('#reg-retry');

  var $cards = $();
  var allRecords = [];

  // ---- Экранирование HTML ----
  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  // ---- Экранирование RegExp ----
  function escapeRegExp(str) {
    return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  // ---- Форматирование даты ----
  var MONTHS = [
    'января', 'февраля', 'марта', 'апреля', 'мая', 'июня',
    'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'
  ];
  function formatDate(iso) {
    var parts = String(iso).split('-');
    if (parts.length !== 3) return iso;
    var d = parseInt(parts[2], 10);
    var m = parseInt(parts[1], 10) - 1;
    var y = parts[0];
    return d + ' ' + (MONTHS[m] || '') + ' ' + y;
  }

  // ---- Построение карточки ----
  function buildCard(record) {
    var safeTitle     = escapeHtml(record.title);
    var safeSection   = escapeHtml(record.section);
    var safeCategory  = escapeHtml(record.category);
    var safeNumber    = escapeHtml(record.number);
    var safeAnnotation= escapeHtml(record.annotation);
    var safeDate      = escapeHtml(record.date);
    var humanDate     = formatDate(record.date);

    return ''
      + '<article class="registry-card"'
      + ' data-section="' + safeSection + '"'
      + ' data-date="' + safeDate + '"'
      + ' data-title="' + safeTitle + '">'
      +   '<p class="registry-card__section">' + safeCategory + ' · ' + safeNumber + '</p>'
      +   '<h2 class="registry-card__title">' + safeTitle + '</h2>'
      +   '<p class="registry-card__desc">' + safeAnnotation + '</p>'
      +   '<p class="registry-card__meta">'
      +     '<time datetime="' + safeDate + '">' + humanDate + '</time>'
      +     ' · <span class="registry-card__section-name">' + safeSection + '</span>'
      +   '</p>'
      + '</article>';
  }

  // ---- Состояния интерфейса ----
  function showLoading() {
    $loading.prop('hidden', false);
    $error.prop('hidden', true);
    $empty.prop('hidden', true);
    $list.prop('hidden', true);
    $status.text('Загрузка записей…');
  }

  function showError(message) {
    $loading.prop('hidden', true);
    $list.prop('hidden', true);
    $empty.prop('hidden', true);
    $error.prop('hidden', false);
    $errorTxt.text(message || 'Проверьте соединение или повторите попытку позже.');
    $status.text('Ошибка загрузки данных.');
  }

  function showList() {
    $loading.prop('hidden', true);
    $error.prop('hidden', true);
    $list.prop('hidden', false);
  }

  // ---- ЗАДАНИЕ 7: индикация активного направления ----
  function updateSortButtons(sortValue) {
    if (!$sortBtns.length) return;
    $sortBtns.each(function () {
      var $btn = $(this);
      var isActive = $btn.data('sort') === sortValue;
      $btn.toggleClass('is-active', isActive);
      $btn.attr('aria-pressed', isActive ? 'true' : 'false');
    });
  }

  // ---- ЗАДАНИЕ 6: Подсветка совпадений в карточке ----
  function highlightCard($card, query) {
    if (!query) return;
    var regex = new RegExp('(' + escapeRegExp(query) + ')', 'gi');

    $card.find('.registry-card__title, .registry-card__desc').each(function () {
      var $el = $(this);
      var original = $el.data('original-html');
      if (original === undefined) {
        original = $el.html();
        $el.data('original-html', original);
      }

      $el.html(original);

      $el.contents().each(function () {
        if (this.nodeType !== 3) return;
        var text = this.nodeValue;
        regex.lastIndex = 0;
        if (!regex.test(text)) return;
        regex.lastIndex = 0;

        var frag = document.createDocumentFragment();
        var lastIndex = 0;
        var m;
        while ((m = regex.exec(text)) !== null) {
          if (m.index > lastIndex) {
            frag.appendChild(document.createTextNode(text.slice(lastIndex, m.index)));
          }
          var span = document.createElement('span');
          span.className = 'search-highlight';
          span.textContent = m[0];
          frag.appendChild(span);
          lastIndex = m.index + m[0].length;
        }
        if (lastIndex < text.length) {
          frag.appendChild(document.createTextNode(text.slice(lastIndex)));
        }
        this.parentNode.replaceChild(frag, this);
      });
    });
  }

  // ---- ЗАДАНИЕ 6: Сброс подсветки ----
  function resetHighlight() {
    $cards.find('.registry-card__title, .registry-card__desc').each(function () {
      var $el = $(this);
      var original = $el.data('original-html');
      if (original !== undefined) {
        $el.html(original);
      }
    });
  }

  // ---- Основная функция фильтрации и сортировки ----
  function applyFilters() {
    if (!$cards.length) return;

    var query   = ($search.val() || '').trim().toLowerCase();
    var section = $section.val();
    var sort    = $sort.val();

    // ЗАДАНИЕ 7: обновляем индикацию активного направления
    updateSortButtons(sort);

    resetHighlight();

    var visible = [];

    $cards.each(function () {
      var $c = $(this);
      var cardSection = $c.data('section');
      var cardTitle   = String($c.data('title')).toLowerCase();
      var cardDesc    = String($c.find('.registry-card__desc').text()).toLowerCase();

      var matchSection = (section === 'all' || cardSection === section);
      var matchQuery   = (!query || cardTitle.indexOf(query) !== -1 || cardDesc.indexOf(query) !== -1);

      if (matchSection && matchQuery) {
        $c.show();
        visible.push($c);
        if (query) highlightCard($c, query);
      } else {
        $c.hide();
      }
    });

    // ---- ЗАДАНИЕ 7: сортировка по дате с индикацией направления ----
    visible.sort(function (a, b) {
      var aDate  = $(a).data('date');
      var bDate  = $(b).data('date');
      var aTitle = String($(a).data('title'));
      var bTitle = String($(b).data('title'));

      switch (sort) {
        case 'date-asc':
          // Сначала старые
          return aDate < bDate ? -1 : aDate > bDate ? 1 : 0;
        case 'date-desc':
          // Сначала новые
          return aDate > bDate ? -1 : aDate < bDate ? 1 : 0;
        case 'title-asc':
          return aTitle.localeCompare(bTitle, 'ru');
        case 'title-desc':
          return bTitle.localeCompare(aTitle, 'ru');
        default:
          return aDate > bDate ? -1 : aDate < bDate ? 1 : 0;
      }
    });

    $.each(visible, function (_, $c) { $list.append($c); });

    var count = visible.length;

    if (count === 0) {
      $status.html('Найдено записей: <strong>0</strong>');
      $empty.prop('hidden', false);
    } else {
      $status.html('Найдено записей: <strong>' + count + '</strong>');
      $empty.prop('hidden', true);
    }
  }

  // ---- ЗАДАНИЕ 6: Сброс фильтров ----
  function resetFilters() {
    $search.val('');
    $section.val('all');
    $sort.val('date-desc');
    updateSortButtons('date-desc');
    resetHighlight();
    applyFilters();
    $search.trigger('focus');
  }

  // ---- Загрузка данных ----
  function loadRecords() {
    showLoading();

    var jsonString = JSON.stringify(window.RECORDS_JSON || []);
    var dataUrl = 'data:application/json;charset=utf-8,' + encodeURIComponent(jsonString);

    $.getJSON(dataUrl)
      .done(function (data) {
        if (!Array.isArray(data) || !data.length) {
          showError('Файл данных пуст или имеет неверный формат.');
          return;
        }

        allRecords = data;

        var html = '';
        $.each(allRecords, function (_, rec) {
          html += buildCard(rec);
        });
        $list.html(html);

        $cards = $list.find('.registry-card');
        $cards.each(function () {
          var $c = $(this);
          $c.data('section', $c.attr('data-section'));
          $c.data('date', $c.attr('data-date'));
          $c.data('title', $c.attr('data-title'));
        });

        showList();
        applyFilters();
      })
      .fail(function (jqxhr, textStatus, errorThrown) {
        var msg = 'Не удалось загрузить данные.';
        if (textStatus === 'parsererror') {
          msg = 'Файл данных повреждён или содержит некорректный JSON.';
        } else if (textStatus === 'timeout') {
          msg = 'Превышено время ожидания ответа. Попробуйте снова.';
        } else if (errorThrown) {
          msg = 'Ошибка: ' + errorThrown;
        }
        showError(msg);
        if (window.console && console.error) {
          console.error('[registry] Ошибка загрузки данных', textStatus, errorThrown);
        }
      });
  }

  // ---- Обработчики ----
  $search.on('input', applyFilters);
  $section.on('change', applyFilters);

  // Скрытый select (если используется где-то ещё)
  $sort.on('change', function () {
    updateSortButtons($(this).val());
    applyFilters();
  });

  // ---- ЗАДАНИЕ 7: клики по кнопкам направления ----
  $sortBtns.on('click', function () {
    var value = $(this).data('sort');
    $sort.val(value);              // синхронизируем скрытый select
    updateSortButtons(value);      // подсвечиваем активную кнопку
    applyFilters();                // пересортировываем
  });

  $reset.on('click', resetFilters);
  $retry.on('click', loadRecords);

  // Escape — сброс поиска
  $search.on('keydown', function (e) {
    if (e.key === 'Escape' || e.keyCode === 27) {
      $search.val('');
      applyFilters();
    }
  });

  loadRecords();
})(jQuery);

// ============================================================
// ЗАДАНИЕ 8: АНИМАЦИИ СТРОК ТАБЛИЦЫ
//   — последовательное появление строк с задержками
//   — подсветка строки при наведении средствами jQuery
// ============================================================
(function ($) {
  var $tables = $('.data-table');
  if (!$tables.length) return;

  // ---- Появление строк с задержкой (как в ЗАДАНИИ 8) ----
  $tables.each(function () {
    var $table = $(this);
    var $rows  = $table.find('tbody tr');

    $rows.each(function (i) {
      var $row = $(this);
      var delay = 0.30 * (i + 1); // 0.30s, 0.60s, 0.90s, ...

      // Ставим начальное состояние через CSS-класс
      $row.addClass('data-table__row--hidden');

      // Плавное появление с задержкой
      $row.css('animation-delay', delay + 's');

      // Убираем скрытие после завершения анимации
      $row.on('animationend', function () {
        $row.removeClass('data-table__row--hidden');
      });

      // Если анимации отключены (prefers-reduced-motion) —
      // снимаем скрытие сразу
      if (window.matchMedia &&
          window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
        $row.removeClass('data-table__row--hidden');
      }
    });
  });

  // ---- Подсветка строки при наведении (jQuery) ----
  $(document).on('mouseenter', '.data-table tbody tr', function () {
    $(this).addClass('data-table__row--hover');
  });

  $(document).on('mouseleave', '.data-table tbody tr', function () {
    $(this).removeClass('data-table__row--hover');
  });
})(jQuery);

// ============================================================
// ЗАДАНИЕ 9: АСИНХРОННЫЙ ПОДСЧЁТ СТАТИСТИКИ
//   — количество записей по разделам и категориям
//   — имитация асинхронной обработки через setInterval
//   — вывод гистограммой средствами CSS
// ============================================================
(function ($) {
  var $stats = $('#stats');
  if (!$stats.length) return;

  var $status     = $('#stats-status');
  var $sectionsEl = $('#stats-sections');
  var $catsEl     = $('#stats-categories');

  // Ждём, пока каталог загрузит данные (records.js -> window.RECORDS_JSON)
  // Периодически проверяем, появились ли данные — если да, запускаем подсчёт
  var waitTimer = setInterval(function () {
    if (Array.isArray(window.RECORDS_JSON) && window.RECORDS_JSON.length) {
      clearInterval(waitTimer);
      startCounting(window.RECORDS_JSON);
    }
  }, 300);

  // ---- Подсчёт статистики ----
  function countBy(records, key) {
    var result = {};
    records.forEach(function (rec) {
      var k = rec[key] || '—';
      result[k] = (result[k] || 0) + 1;
    });
    return result;
  }

  // ---- Создание DOM-элемента строки гистограммы ----
  function makeBar(label, value, max) {
    var percent = max > 0 ? Math.round((value / max) * 100) : 0;

    var $row = $('<div class="stats__bar-row">');
    var $label = $('<span class="stats__bar-label">').text(label);
    var $track = $('<div class="stats__bar-track">');
    var $fill  = $('<div class="stats__bar-fill">');
    var $val   = $('<span class="stats__bar-value">').text(value);

    $fill.css('width', '0%');
    $track.append($fill);
    $row.append($label, $track, $val);

    // Плавная анимация заполнения — через requestAnimationFrame,
    // чтобы браузер успел отрисовать стартовое состояние
    requestAnimationFrame(function () {
      requestAnimationFrame(function () {
        $fill.css('width', percent + '%');
      });
    });

    return $row;
  }

  // ---- Постепенный вывод строк через setInterval ----
  function renderChart($container, data, onDone) {
    $container.empty();

    var entries = Object.keys(data).map(function (k) {
      return { label: k, value: data[k] };
    });

    // Сортируем по убыванию количества
    entries.sort(function (a, b) { return b.value - a.value; });

    var max = entries.reduce(function (m, e) { return Math.max(m, e.value); }, 0);
    var index = 0;

    var timer = setInterval(function () {
      if (index >= entries.length) {
        clearInterval(timer);
        if (typeof onDone === 'function') onDone();
        return;
      }
      var e = entries[index++];
      $container.append(makeBar(e.label, e.value, max));
      $status.text('Обработка… выведено строк: ' + index + ' из ' + entries.length);
    }, 220); // задержка 220 мс между строками — имитация асинхронной обработки
  }

  // ---- Основной сценарий ----
  function startCounting(records) {
    $stats.prop('hidden', false);

    var totalRecords = records.length;
    $status.text('Всего записей: ' + totalRecords + '. Идёт подсчёт по разделам…');

    // Небольшая стартовая задержка — имитация «серверной» обработки
    setTimeout(function () {
      var bySection = countBy(records, 'section');

      renderChart($sectionsEl, bySection, function () {
        $status.text('Разделы посчитаны. Идёт подсчёт по категориям…');

        setTimeout(function () {
          var byCategory = countBy(records, 'category');

          renderChart($catsEl, byCategory, function () {
            $status.text(
              'Готово. Всего записей: ' + totalRecords +
              ', разделов: ' + Object.keys(bySection).length +
              ', категорий: ' + Object.keys(byCategory).length + '.'
            );
          });
        }, 400);
      });
    }, 400);
  }
})(jQuery);

// ============================================================
// ЗАДАНИЕ 2 (knowledge.html): ФОРМА ПРОВЕРКИ ЗНАНИЙ
// ============================================================
(function ($) {
  var $form = $('#knowledge-form');
  if (!$form.length) return;

  var $dateInput = $('#date');
  var $checkNumberInput = $('#check-number');

  // 1. Инициализация datepicker и установка сегодняшней даты
  // Формат даты: dd.mm.yy (например, 14.10.2026)
  $dateInput.datepicker({
    dateFormat: 'dd.mm.yy',
    defaultDate: new Date(), // Устанавливает сегодняшнюю дату по умолчанию
    // Можно также использовать 'minDate: 0', чтобы нельзя было выбрать прошедшие даты
    // minDate: 0
  });

  // Устанавливаем сегодняшнюю дату вручную, так как defaultDate не всегда срабатывает при инициализации
  $dateInput.datepicker('setDate', new Date());


  // 2. Генерация номера проверки
  function generateCheckNumber() {
    var now = new Date();
    var year = now.getFullYear();
    var month = String(now.getMonth() + 1).padStart(2, '0'); // Месяцы с 0
    var day = String(now.getDate()).padStart(2, '0');
    var randomPart = Math.floor(1000 + Math.random() * 9000); // 4-значное случайное число
    return 'KN-' + year + month + day + '-' + randomPart;
  }

  $checkNumberInput.val(generateCheckNumber());


  // 3. Обработка отправки формы
  $form.on('submit', function (event) {
    event.preventDefault(); // Предотвращаем стандартную отправку

    // Простая валидация
    var surname = $('#surname').val().trim();
    var group = $('#group').val().trim();
    var email = $('#email').val().trim();

    if (!surname || !group || !email) {
      alert('Пожалуйста, заполните все обязательные поля.');
      return;
    }

    // Здесь можно добавить логику отправки данных на сервер
    // Например, через AJAX:
    // $.ajax({
    //   url: '/api/start-check',
    //   method: 'POST',
    //   data: $form.serialize(),
    //   success: function(response) {
    //     // Перенаправление на страницу с вопросами
    //     window.location.href = 'test.html';
    //   },
    //   error: function() {
    //     alert('Ошибка при отправке формы. Попробуйте еще раз.');
    //   }
    // });

    // Пока просто выводим данные в консоль и имитируем переход
    console.log('Форма отправлена:', {
      surname: surname,
      group: group,
      date: $dateInput.val(),
      email: email,
      checkNumber: $checkNumberInput.val()
    });

    alert('Форма успешно заполнена! Номер вашей проверки: ' + $checkNumberInput.val());
    // В будущем здесь будет переход на страницу с вопросами:
    // window.location.href = 'test.html';
  });

})(jQuery);

// ============================================================
// ЗАДАНИЯ 3-9: ПОЛНАЯ ЛОГИКА ПРОВЕРКИ ЗНАНИЙ (knowledge.html)
// ============================================================
(function ($) {
  var $infoForm = $('#info-form');
  if (!$infoForm.length) return;

  var STORAGE_HISTORY_KEY = 'socshield-knowledge-history';
  var STORAGE_COUNTER_KEY = 'socshield-knowledge-counter';

  var totalQuestions = 10;
  var correctAnswers = {
    q1: 'c', q2: 'b', q3: 'b', q4: 'b', q5: 'c',
    q6: 'b', q7: 'b', q8: 'b', q9: 'c', q10: 'b'
  };
  var correctOrder = ['1', '2', '3', '4'];

  var userData = {};
  var answeredQuestions = {};
  var sortableChecked = false;   // проверялась ли кнопкой
  var sortableCorrect = false;   // верный ли порядок
  var quizInitialized = false;

  // ============================================================
  // 1. Datepicker (без будущих дат)
  // ============================================================
  $('#date').datepicker({
    dateFormat: 'dd.mm.yy',
    defaultDate: new Date(),
    maxDate: 0
  });
  $('#date').datepicker('setDate', new Date());

  // ============================================================
  // 2. Номер проверки
  // ============================================================
  // Функция для получения инициалов
  function getInitials() {
    var surname = $('#surname').val().trim();
    var firstname = $('#firstname').val().trim();
    var initials = '';

    if (surname) {
      initials += surname.charAt(0).toUpperCase();
    }
    if (firstname) {
      initials += firstname.charAt(0).toUpperCase();
    }
    
    // Если поля пустые, возвращаем 'XX'
    return initials || 'XX';
  }

  // Генерируем номер ОДИН РАЗ при загрузке, чтобы не сбрасывать счетчик
  function generateInitialCheckNumber() {
    var now = new Date();
    var year = now.getFullYear();
    var stored = parseInt(localStorage.getItem(STORAGE_COUNTER_KEY) || '0', 10);
    if (isNaN(stored) || stored < 0) stored = 0;
    var next = stored + 1;
    localStorage.setItem(STORAGE_COUNTER_KEY, String(next));
    // Изначально инициалы будут 'XX', так как поля пустые
    return 'XX-' + year + '-' + String(next).padStart(4, '0');
  }

  function resetCounterAndGetNumber() {
    try { localStorage.removeItem(STORAGE_COUNTER_KEY); } catch (e) {}
    return generateInitialCheckNumber();
  }

  $('#check-number').val(generateInitialCheckNumber());

  // Обновляем ТОЛЬКО инициалы при вводе фамилии или имени
  $('#surname, #firstname').on('input', function() {
    var currentNumber = $('#check-number').val();
    // Разбиваем номер на части: [Инициалы, Год, Порядковый номер]
    var parts = currentNumber.split('-');
    
    // Если структура номера верная (3 части)
    if (parts.length === 3) {
      var initials = getInitials();
      // Меняем только первую часть (инициалы), остальное оставляем как есть
      parts[0] = initials;
      $('#check-number').val(parts.join('-'));
    }
  });



  // ============================================================
  // 3. Валидация имени / группы / даты
  // ============================================================
  var NAME_REGEX = /^[А-Яа-яЁёA-Za-z]+$/;

  function isMeaningfulWord(word) {
    if (word.length < 2) return false;
    if (/(.)\1{2,}/i.test(word)) return false;

    var unique = {};
    for (var i = 0; i < word.length; i++) {
      unique[word[i].toLowerCase()] = true;
    }
    if (Object.keys(unique).length < 2) return false;

    var keyboardRows = [
      'qwertyuiop', 'asdfghjkl', 'zxcvbnm',
      'йцукенгшщзхъ', 'фывапролджэ', 'ячсмитьбю'
    ];
    var lower = word.toLowerCase();
    for (var k = 0; k < keyboardRows.length; k++) {
      if (keyboardRows[k].indexOf(lower) !== -1) return false;
    }
    return true;
  }

  function validateName(value, label) {
    var v = value.trim();
    if (!v) return { ok: false, msg: 'Пожалуйста, введите ' + label + '.' };
    if (v.length < 2) return { ok: false, msg: label + ' должно содержать минимум 2 символа.' };
    if (v.length > 50) return { ok: false, msg: label + ' слишком длинное (макс. 50).' };
    if (!NAME_REGEX.test(v)) return { ok: false, msg: 'В ' + label + ' допустимы только буквы.' };
    if (!isMeaningfulWord(v.replace(/[\-' ]/g, ''))) {
      return { ok: false, msg: 'Похоже, ' + label + ' введено некорректно.' };
    }
    return { ok: true };
  }

  var GROUP_REGEX = /^(?:[А-Яа-яA-Za-z]{1,4}-?\d{2,3}|\d{2,3})$/;

  function validateGroup(value) {
    var v = value.trim();
    if (!v) return { ok: false, msg: 'Пожалуйста, укажите учебную группу.' };
    if (v.length < 2) return { ok: false, msg: 'Номер группы слишком короткий.' };
    if (v.length > 10) return { ok: false, msg: 'Номер группы слишком длинный.' };
    if (!GROUP_REGEX.test(v)) {
      return { ok: false, msg: 'Формат: буквы и цифры (например, П-21, ИС-31, 21).' };
    }
    return { ok: true };
  }

  // Проверка даты — не будущая.
  function validateDate() {
    var v = $('#date').val().trim();
    if (!v) return { ok: false, msg: 'Пожалуйста, выберите дату.' };

    var parts = v.split('.');
    if (parts.length !== 3) return { ok: false, msg: 'Некорректный формат даты.' };

    var d = parseInt(parts[0], 10);
    var m = parseInt(parts[1], 10) - 1;
    var y = parseInt(parts[2], 10);

    var selected = new Date(y, m, d);
    if (isNaN(selected.getTime())) return { ok: false, msg: 'Введите корректную дату.' };

    // Сброс времени до конца сегодняшнего дня
    var today = new Date();
    today.setHours(23, 59, 59, 999);

    if (selected.getTime() > today.getTime()) {
      return { ok: false, msg: 'Дата проверки не может быть в будущем.' };
    }
    return { ok: true };
  }

  function validateForm() {
    var isValid = true;
    $('.error-message').text('');
    $('.form-input').removeClass('input-error input-success');

    var s = validateName($('#surname').val(), 'фамилию');
    if (!s.ok) { $('#error-surname').text(s.msg); $('#surname').addClass('input-error'); isValid = false; }
    else { $('#surname').addClass('input-success'); }

    var f = validateName($('#firstname').val(), 'имя');
    if (!f.ok) { $('#error-firstname').text(f.msg); $('#firstname').addClass('input-error'); isValid = false; }
    else { $('#firstname').addClass('input-success'); }

    var g = validateGroup($('#group').val());
    if (!g.ok) { $('#error-group').text(g.msg); $('#group').addClass('input-error'); isValid = false; }
    else { $('#group').addClass('input-success'); }

    var dt = validateDate();
    if (!dt.ok) { $('#error-date').text(dt.msg); $('#date').addClass('input-error'); isValid = false; }
    else { $('#date').addClass('input-success'); }

    var email = $('#email').val().trim();
    var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email) {
      $('#error-email').text('Пожалуйста, введите адрес электронной почты.');
      $('#email').addClass('input-error'); isValid = false;
    } else if (!emailRegex.test(email)) {
      $('#error-email').text('Введите корректный адрес (например, student@example.com).');
      $('#email').addClass('input-error'); isValid = false;
    } else {
      $('#email').addClass('input-success');
    }

    return isValid;
  }

  $('#surname, #firstname, #group, #email, #date').on('blur input change', validateForm);

  // ============================================================
  // 4. Переход к тесту
  // ============================================================
  $infoForm.on('submit', function(event) {
    event.preventDefault();

    if (!validateForm()) {
      alert('Пожалуйста, исправьте ошибки в форме.');
      return;
    }

    userData = {
      surname: $('#surname').val().trim(),
      firstname: $('#firstname').val().trim(),
      group: $('#group').val().trim(),
      date: $('#date').val(),
      email: $('#email').val().trim(),
      checkNumber: $('#check-number').val()
    };

    $('#quiz-user-name').text(userData.surname + ' ' + userData.firstname);
    $('#quiz-user-group').text(userData.group);

    $('#step-form').prop('hidden', true);
    $('#step-quiz').prop('hidden', false);

    if (!quizInitialized) {
      initQuiz();
      quizInitialized = true;
    }

    $('html, body').animate({ scrollTop: 0 }, 300);
  });

  $('#back-to-form').on('click', function() {
    $('#step-quiz').prop('hidden', true);
    $('#step-form').prop('hidden', false);
    $('html, body').animate({ scrollTop: 0 }, 300);
  });

  // ============================================================
  // 5. Инициализация теста
  // ============================================================
  function initQuiz() {
    $('#quiz-tabs').tabs();

    $('#progressbar').progressbar({
      value: 0,
      create: function() {
        $(this).find('.progress-label').text('0%');
      },
      change: function() {
        var val = $(this).progressbar('value');
        $(this).find('.progress-label').text(Math.round(val) + '%');
      }
    });

    $('#confidence-slider').slider({
      min: 0, max: 10, value: 5,
      slide: function(event, ui) {
        $('#confidence-value').text(ui.value);
      }
    });

    $('#step-quiz').on('change', 'input[type="radio"]', function() {
      var name = $(this).attr('name');
      if (!answeredQuestions[name]) answeredQuestions[name] = true;
      updateState();
    });

    // Sortable — только перетаскивание
    $('#sortable-steps').sortable({
      axis: 'y',
      cursor: 'grabbing',
      handle: '.sortable-list__text',
      update: function() {
        // При любом перемещении сбрасываем прошлую проверку
        sortableChecked = false;
        sortableCorrect = false;
        $('#sortable-result').text('').css('color', '');
        updateState();
      }
    });

    // Кнопки ↑/↓ для мобильных
    $('#sortable-steps').on('click', '.sortable-arrow', function() {
      var $li = $(this).closest('li');
      var dir = $(this).data('dir');

      if (dir === 'up') {
        var $prev = $li.prev('li');
        if ($prev.length) $li.insertBefore($prev);
      } else {
        var $next = $li.next('li');
        if ($next.length) $li.insertAfter($next);
      }

      // Сбрасываем прошлую проверку
      sortableChecked = false;
      sortableCorrect = false;
      $('#sortable-result').text('').css('color', '');
      updateState();
    });

    // Кнопка «Проверить порядок»
    $('#check-sortable').on('click', function() {
      var current = $('#sortable-steps').sortable('toArray', { attribute: 'data-step' });
      sortableCorrect = JSON.stringify(current) === JSON.stringify(correctOrder);
      sortableChecked = true;

      if (sortableCorrect) {
        $('#sortable-result').text('✅ Порядок верный!').css('color', 'var(--color-success)');
      } else {
        $('#sortable-result').text('❌ Порядок неверный. Попробуйте ещё раз.').css('color', 'var(--color-danger)');
      }
      updateState();
    });
  }

  // ============================================================
  // 6. Обновление состояния (прогресс + доступность кнопки)
  // ============================================================
  function updateState() {
    var answered = Object.keys(answeredQuestions).length;
    var percent = Math.round((answered / totalQuestions) * 100);
    $('#progressbar').progressbar('value', percent);
    $('#progress-text').text('Отвечено вопросов: ' + answered + ' из ' + totalQuestions);

    var allAnswered = answered === totalQuestions;
    var canFinish = allAnswered && sortableChecked && sortableCorrect;

    $('#finish-test').prop('disabled', !canFinish);

    if (canFinish) {
      $('#finish-hint').text('Всё готово! Нажмите «Завершить тест».').css('color', 'var(--color-success)');
    } else if (!allAnswered && !(sortableChecked && sortableCorrect)) {
      $('#finish-hint').text('Ответьте на все ' + totalQuestions + ' вопросов и правильно расставьте шаги (нажмите «Проверить порядок»).').css('color', 'var(--color-muted)');
    } else if (!allAnswered) {
      $('#finish-hint').text('Осталось ответить: ' + (totalQuestions - answered) + ' вопрос(ов).').css('color', 'var(--color-muted)');
    } else if (!sortableChecked) {
      $('#finish-hint').text('Нажмите «Проверить порядок» в разделе «Сортировка действий».').css('color', 'var(--color-muted)');
    } else if (!sortableCorrect) {
      $('#finish-hint').text('Порядок в разделе «Сортировка действий» неверный — исправьте и проверьте снова.').css('color', 'var(--color-danger)');
    }
  }

  // ============================================================
  // 7. Завершение теста
  // ============================================================
  $('#finish-test').on('click', function() {
    if ($(this).prop('disabled')) return;

    var correctCount = 0;
    $.each(correctAnswers, function(q, correct) {
      if ($('input[name="' + q + '"]:checked').val() === correct) correctCount++;
    });

    var percent = Math.round((correctCount / totalQuestions) * 100);
    var level, levelClass, message;

    if (percent >= 80) {
      level = 'Высокий'; levelClass = 'high';
      message = 'Отличный результат! Вы хорошо разбираетесь в теме.';
    } else if (percent >= 50) {
      level = 'Удовлетворительный'; levelClass = 'mid';
      message = 'Неплохо, но стоит повторить некоторые разделы.';
    } else {
      level = 'Низкий'; levelClass = 'low';
      message = 'Рекомендуем внимательно изучить материалы портала.';
    }

    $('#dialog-correct-count').text(correctCount);
    $('#dialog-percent').text(percent + '%');
    $('#dialog-level').text(level);
    $('#dialog-message').text(message);
    $('#dialog-check-number').text(userData.checkNumber);

    var resultData = {
      surname: userData.surname,
      firstname: userData.firstname,
      fullName: userData.surname + ' ' + userData.firstname,
      group: userData.group,
      date: userData.date,
      email: userData.email,
      checkNumber: userData.checkNumber,
      correctCount: correctCount,
      totalQuestions: totalQuestions,
      percent: percent,
      level: level,
      levelClass: levelClass,
      message: message,
      confidence: $('#confidence-slider').slider('value'),
      sortableCorrect: sortableCorrect,
      savedAt: new Date().toISOString()
    };

    saveToHistory(resultData);
    renderHistory();

    $('#result-dialog').dialog({
      modal: true,
      width: 480,
      buttons: {
        'Понятно': function() { $(this).dialog('close'); }
      }
    });
  });

  // ============================================================
  // 8. История
  // ============================================================
  function loadHistory() {
    try {
      var raw = localStorage.getItem(STORAGE_HISTORY_KEY);
      if (!raw) return [];
      var data = JSON.parse(raw);
      return Array.isArray(data) ? data : [];
    } catch (e) { return []; }
  }

  function saveToHistory(record) {
    var history = loadHistory();
    history.unshift(record);
    if (history.length > 20) history = history.slice(0, 20);
    try { localStorage.setItem(STORAGE_HISTORY_KEY, JSON.stringify(history)); } catch (e) {}
  }

  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function renderHistory() {
    var history = loadHistory();
    var $list = $('#history-list');
    var $empty = $('#history-empty');

    if (!history.length) {
      $list.empty();
      $empty.show();
      return;
    }

    $empty.hide();
    var html = '';
    $.each(history, function(_, item) {
      var lvlClass = 'history-item__level--' + (item.levelClass || 'mid');
      var fullName = item.fullName || ((item.surname || '') + ' ' + (item.firstname || '')).trim() || '—';
      html += ''
        + '<div class="history-item">'
        +   '<div class="history-item__head">'
        +     '<span class="history-item__name">' + escapeHtml(fullName) + ' (' + escapeHtml(item.group || '—') + ')</span>'
        +     '<span class="history-item__date">' + escapeHtml(item.date || '') + '</span>'
        +   '</div>'
        +   '<div class="history-item__meta">'
        +     '<span>№ ' + escapeHtml(item.checkNumber || '—') + '</span>'
        +     '<span>Результат: ' + item.correctCount + '/' + item.totalQuestions + ' (' + item.percent + '%)</span>'
        +     '<span class="history-item__level ' + lvlClass + '">' + escapeHtml(item.level || '—') + '</span>'
        +     '<span>Уверенность: ' + item.confidence + '/10</span>'
        +     '<span>Сортировка: ' + (item.sortableCorrect ? '✅' : '❌') + '</span>'
        +   '</div>'
        + '</div>';
    });
    $list.html(html);
  }

  $('#clear-history').on('click', function() {
    if (window.confirm('Очистить всю историю проверок и сбросить счётчик номеров?')) {
      try {
        localStorage.removeItem(STORAGE_HISTORY_KEY);
        localStorage.removeItem(STORAGE_COUNTER_KEY);
      } catch (e) {}
      $('#check-number').val(resetCounterAndGetNumber());
      renderHistory();
    }
  });

  renderHistory();

})(jQuery);

// ============================================================
// БОКОВАЯ НАВИГАЦИЯ (sidenav): плавный скролл и подсветка
// ============================================================
(function ($) {
    var $sidenavLinks = $('.sidenav a[href^="#"]');
    if (!$sidenavLinks.length) return;

    // 1. Плавный скролл и мгновенная подсветка при клике
    $sidenavLinks.on('click', function (e) {
        var $this = $(this);
        var targetId = $this.attr('href');

        // Убираем подсветку у всех ссылок
        $sidenavLinks.removeClass('sidenav__link--active');
        // Добавляем класс активной ссылке
        $this.addClass('sidenav__link--active');
    });

    // 2. Подсветка при скролле (Scroll Spy)
    var $sections = $('main section[id]'); // Находим все секции с id
    if (!$sections.length) return;

    function updateActiveLink() {
        var scrollPos = $(window).scrollTop() + 120; // Небольшой отступ
        var currentId = '';

        $sections.each(function () {
            var $section = $(this);
            if ($section.offset().top <= scrollPos) {
                currentId = $section.attr('id');
            }
        });

        if (currentId) {
            var $newActiveLink = $sidenavLinks.filter('a[href="#' + currentId + '"]');
            if (!$newActiveLink.hasClass('sidenav__link--active')) {
                $sidenavLinks.removeClass('sidenav__link--active');
                $newActiveLink.addClass('sidenav__link--active');
            }
        }
    }

    // Обновляем при скролле и при загрузке
    $(window).on('scroll', updateActiveLink);
    updateActiveLink();
})(jQuery);